
import img1 from '../../src/electric.jpg'
import img2 from '../../src/hair_dresser.jpg'
import img3 from '../../src/plumba.jpg'

const ServiceList = [
   {
    name: "HairStyle with Us",
    email:"hairclean@gmail.com",
    review:'7',
    avator: img2,
    coord:{latitude:-25.747868, longitude: 28.2292714}

},{
    name: "wiring with Us",
    email:"powerinstallation@gmail.com",
    review:'4',
    avator: img1,
    coord:{latitude:-25.742088, longitude: 28.217233}
},{

    name: "Plumber with Us",
    email:"plumber@gmail.com",
    review:'10',
    avator: img3,
    coord:{latitude:-25.741209, longitude: 28.218282}
}, 

]










export default ServiceList;